package com.example.abigailsaadeh.getlocation;

import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MAIN ACTIVITY";
    private FusedLocationProviderClient client;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestPermission();

        client = LocationServices.getFusedLocationProviderClient(this);

        Button button = findViewById(R.id.getLocation);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ActivityCompat.checkSelfPermission(MainActivity.this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                client.getLastLocation().addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {

                        if(location != null){
                            Log.d(TAG, "location is not null");

                            TextView textView = findViewById(R.id.location);

                            //SET LOCATION TO NEW LATLNG OBJECT
                            LatLng locationLatLng = new LatLng(location.getLatitude(),location.getLongitude());

                            //USE LATLNG OBJECT TO GET ADDRESS USING GEOCODER
                            //PASS ADDRESS INTO SET TEXT FUNCTION CALL

                            //SET TEXT TO ADDRESS
                            textView.setText(getAddress(locationLatLng));

                        }


                    }
                });

            }
        });
    }


    //Get Address String
    private String getAddress(LatLng locationLatLng){
        String myCity  = "";
        Geocoder geocoder = new Geocoder(MainActivity.this);
        try {
            List<Address> addressList = geocoder.getFromLocation(locationLatLng.latitude,locationLatLng.longitude,1);
            //String address = addressList.get(0).getAddressLine(0);
            myCity = addressList.get(0).getAddressLine(0);

        } catch (IOException e) {
            e.printStackTrace();
        }

        //RETURNS ADDRESS STRING
        return myCity;

    }

    private void requestPermission(){
        ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION},1);
        Log.d(TAG, "requesting permissions");

    }
}
