package com.example.mathuchoco.myapplication;

import static org.junit.Assert.*;

/**
 * Created by mathuchoco on 9/9/18.
 */
public class MainActivityTest {

}