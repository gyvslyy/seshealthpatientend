package com.example.mathuchoco.myapplication;

/**
 * Created by mathuchoco on 10/9/18.
 */

class MainActivityImpl extends MainActivity {
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
